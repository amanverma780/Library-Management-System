--
-- (c) Kitodo. Key to digital objects e. V. <contact@kitodo.org>
--
-- This file is part of the Kitodo project.
--
-- It is licensed under GNU General Public License version 3 or later.
--
-- For the full copyright and license information, please read the
-- GPL3-License.txt file that was distributed with this source code.
--

--
-- Migration: Increasing the maximum length of column scriptPath in table task.
--            This allows longer paths and parameters to be saved.
--

ALTER TABLE task MODIFY COLUMN scriptPath VARCHAR(500);
